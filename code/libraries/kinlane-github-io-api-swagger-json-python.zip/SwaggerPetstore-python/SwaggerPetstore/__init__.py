#!/usr/bin/env python
"""Add all of the modules in the current directory to __all__"""
import os

# import models into package

from .models.api import Api

from .models.tag import Tag

from .models.note import Note

from .models.snippet import Snippet

from .models.url import Url

from .models.image import Image

from .models.screenshot import Screenshot

from .models.buildingblock import Buildingblock

from .models.log import Log

from .models.definition import Definition


# import apis into package

from .notes_api import NotesApi

from .building_blocks_api import BuildingBlocksApi

from .tags_api import TagsApi

from .logs_api import LogsApi

from .api_api import APIApi

from .definition_code_api import DefinitionCodeApi

from .screenshots_api import ScreenshotsApi

from .ur_ls_api import URLsApi

from .definitions_api import DefinitionsApi

from .images_api import ImagesApi


# import ApiClient
from .swagger import ApiClient

__all__ = []

for module in os.listdir(os.path.dirname(__file__)):
  if module != '__init__.py' and module[-3:] == '.py':
    __all__.append(module[:-3])
