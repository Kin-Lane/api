using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Screenshot {
    

    /* name of the screenshot */
    
    public string Name { get; set; }

    

    /* path of the screenshot */
    
    public string Path { get; set; }

    

    /* type of screenshot */
    
    public string Type { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Screenshot {\n");
      
      sb.Append("  Name: ").Append(Name).Append("\n");
      
      sb.Append("  Path: ").Append(Path).Append("\n");
      
      sb.Append("  Type: ").Append(Type).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}