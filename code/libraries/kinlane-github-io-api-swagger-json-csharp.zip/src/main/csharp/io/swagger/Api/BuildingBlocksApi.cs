using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class BuildingBlocksApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public BuildingBlocksApi(String basePath = "https://api.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// retrieve an APIs building blocks retrieve an APIs building blocks
    /// </summary>
    /// <param name="ApiId">id for the API</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<buildingblock>  GetAPIBuildingBlocks (string ApiId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/api/{api_id}/buildingblocks/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<buildingblock>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<buildingblock>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<buildingblock>) ApiInvoker.deserialize(response, typeof(List<buildingblock>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add an API building block add an API building block
    /// </summary>
    /// <param name="ApiId">id for the API</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="BuildingBlockApi">id for the building block</param>
     /// <param name="OrganizationId">id for the organization</param>
     /// <param name="ToolId">id for the tool</param>
     /// <param name="Url">the url for the building block</param>
    
    /// <returns></returns>
    public List<buildingblock>  AddAPIBuildingBlock (string ApiId, string Appid, string Appkey, int? BuildingBlockApi, int? OrganizationId, int? ToolId, string Url) {
      // create path and map variables
      var path = "/api/{api_id}/buildingblocks/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (BuildingBlockApi != null){
        queryParams.Add("building_block_api", apiInvoker.ParameterToString(BuildingBlockApi));
      }
      if (OrganizationId != null){
        queryParams.Add("organization_id", apiInvoker.ParameterToString(OrganizationId));
      }
      if (ToolId != null){
        queryParams.Add("tool_id", apiInvoker.ParameterToString(ToolId));
      }
      if (Url != null){
        queryParams.Add("url", apiInvoker.ParameterToString(Url));
      }
      

      

      

      try {
        if (typeof(List<buildingblock>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<buildingblock>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<buildingblock>) ApiInvoker.deserialize(response, typeof(List<buildingblock>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete an API building block delete an API building block
    /// </summary>
    /// <param name="ApiId">id for the API</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="BuildingblockId">id for the building block</param>
    
    /// <returns></returns>
    public List<buildingblock>  DeleteAPIBuildingBlocks (string ApiId, string Appid, string Appkey, string BuildingblockId) {
      // create path and map variables
      var path = "/api/{api_id}/buildingblocks/{buildingblock_id}".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId)).Replace("{" + "buildingblock_id" + "}", apiInvoker.ParameterToString(BuildingblockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<buildingblock>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<buildingblock>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<buildingblock>) ApiInvoker.deserialize(response, typeof(List<buildingblock>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
