using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Snippet {
    

    /* content of the snippet */
    
    public string Content { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Snippet {\n");
      
      sb.Append("  Content: ").Append(Content).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}