using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Buildingblock {
    

    /* url of the building block */
    
    public string Url { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Buildingblock {\n");
      
      sb.Append("  Url: ").Append(Url).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}