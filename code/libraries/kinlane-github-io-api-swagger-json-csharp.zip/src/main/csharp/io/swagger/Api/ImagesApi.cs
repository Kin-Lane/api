using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class ImagesApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public ImagesApi(String basePath = "https://api.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// retrieve an APIs images retrieve an APIs images
    /// </summary>
    /// <param name="ApiId">id for the API</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<image>  GetAPIImages (string ApiId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/api/{api_id}/images/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<image>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<image>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<image>) ApiInvoker.deserialize(response, typeof(List<image>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add an API image add an API image
    /// </summary>
    /// <param name="ApiId">id for the API</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Name">name of the image</param>
     /// <param name="Path">path of the image</param>
     /// <param name="Type">type of image</param>
    
    /// <returns></returns>
    public List<image>  AddAPIImage (string ApiId, string Appid, string Appkey, string Name, string Path, string Type) {
      // create path and map variables
      var path = "/api/{api_id}/images/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Name != null){
        queryParams.Add("name", apiInvoker.ParameterToString(Name));
      }
      if (Path != null){
        queryParams.Add("path", apiInvoker.ParameterToString(Path));
      }
      if (Type != null){
        queryParams.Add("type", apiInvoker.ParameterToString(Type));
      }
      

      

      

      try {
        if (typeof(List<image>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<image>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<image>) ApiInvoker.deserialize(response, typeof(List<image>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete an API image delete an API image
    /// </summary>
    /// <param name="ApiId">id for the API</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="ImageId">id for the image</param>
    
    /// <returns></returns>
    public List<image>  DeleteAPIImage (string ApiId, string Appid, string Appkey, string ImageId) {
      // create path and map variables
      var path = "/api/{api_id}/images/{image_id}".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId)).Replace("{" + "image_id" + "}", apiInvoker.ParameterToString(ImageId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<image>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<image>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<image>) ApiInvoker.deserialize(response, typeof(List<image>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
