using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Log {
    

    /* type of log */
    
    public string Type { get; set; }

    

    /* text of note */
    
    public string Note { get; set; }

    

    /* details of log */
    
    public string Details { get; set; }

    

    /* log date */
    
    public string LogDate { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Log {\n");
      
      sb.Append("  Type: ").Append(Type).Append("\n");
      
      sb.Append("  Note: ").Append(Note).Append("\n");
      
      sb.Append("  Details: ").Append(Details).Append("\n");
      
      sb.Append("  LogDate: ").Append(LogDate).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}