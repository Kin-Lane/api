using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class APIApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public APIApi(String basePath = "https://api.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// retrieves all apis retrieves all apis
    /// </summary>
    /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Query">a text query to search across APIs</param>
    
    /// <returns></returns>
    public List<api>  GetAPIs (string Appid, string Appkey, string Query) {
      // create path and map variables
      var path = "/api/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Query != null){
        queryParams.Add("query", apiInvoker.ParameterToString(Query));
      }
      

      

      

      try {
        if (typeof(List<api>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<api>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<api>) ApiInvoker.deserialize(response, typeof(List<api>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add api add api
    /// </summary>
    /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Name">name of the API</param>
     /// <param name="About">details about the API</param>
     /// <param name="Rank">ranking of API</param>
     /// <param name="OrganizationId">organization ID for the API</param>
    
    /// <returns></returns>
    public List<api>  AddAPI (string Appid, string Appkey, string Name, string About, string Rank, string OrganizationId) {
      // create path and map variables
      var path = "/api/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Name != null){
        queryParams.Add("name", apiInvoker.ParameterToString(Name));
      }
      if (About != null){
        queryParams.Add("about", apiInvoker.ParameterToString(About));
      }
      if (Rank != null){
        queryParams.Add("rank", apiInvoker.ParameterToString(Rank));
      }
      if (OrganizationId != null){
        queryParams.Add("organization_id", apiInvoker.ParameterToString(OrganizationId));
      }
      

      

      

      try {
        if (typeof(List<api>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<api>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<api>) ApiInvoker.deserialize(response, typeof(List<api>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// retrieve an API retrieve an API
    /// </summary>
    /// <param name="ApiId">id for the API</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<api>  GetAPI (string ApiId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/api/{api_id}/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<api>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<api>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<api>) ApiInvoker.deserialize(response, typeof(List<api>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// update an API update an API
    /// </summary>
    /// <param name="ApiId">id for the API</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Name">name of the API</param>
     /// <param name="About">details about the API</param>
     /// <param name="Rank">ranking of API</param>
     /// <param name="OrganizationId">organization ID for the API</param>
    
    /// <returns></returns>
    public List<api>  UpdateAPI (string ApiId, string Appid, string Appkey, string Name, string About, string Rank, string OrganizationId) {
      // create path and map variables
      var path = "/api/{api_id}/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Name != null){
        queryParams.Add("name", apiInvoker.ParameterToString(Name));
      }
      if (About != null){
        queryParams.Add("about", apiInvoker.ParameterToString(About));
      }
      if (Rank != null){
        queryParams.Add("rank", apiInvoker.ParameterToString(Rank));
      }
      if (OrganizationId != null){
        queryParams.Add("organization_id", apiInvoker.ParameterToString(OrganizationId));
      }
      

      

      

      try {
        if (typeof(List<api>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<api>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<api>) ApiInvoker.deserialize(response, typeof(List<api>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete an API delete an API
    /// </summary>
    /// <param name="ApiId">id for the API</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<api>  DeleteAPI (string ApiId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/api/{api_id}/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<api>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<api>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<api>) ApiInvoker.deserialize(response, typeof(List<api>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
