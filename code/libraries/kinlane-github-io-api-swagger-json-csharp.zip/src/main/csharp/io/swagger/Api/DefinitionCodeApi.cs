using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class DefinitionCodeApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public DefinitionCodeApi(String basePath = "https://api.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// generate php array parameters generate php array parameters
    /// </summary>
    /// <param name="ApiId">id for the api item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Filterobject">the api definition object to filter by</param>
    
    /// <returns></returns>
    public List<snippet>  GeneratePHPArrayParameters (string ApiId, string Appid, string Appkey, string Filterobject) {
      // create path and map variables
      var path = "/api/{api_id}/definitions/code/php/generate/definition/parameters/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Filterobject != null){
        queryParams.Add("filterobject", apiInvoker.ParameterToString(Filterobject));
      }
      

      

      

      try {
        if (typeof(List<snippet>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<snippet>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<snippet>) ApiInvoker.deserialize(response, typeof(List<snippet>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// generate php array parameters generate php array parameters
    /// </summary>
    /// <param name="ApiId">id for the api item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Filterpath">the api path to filter by</param>
     /// <param name="Filterverb">the api verb to filter by</param>
    
    /// <returns></returns>
    public List<snippet>  GeneratePHPArrayParameters_1 (string ApiId, string Appid, string Appkey, string Filterpath, string Filterverb) {
      // create path and map variables
      var path = "/api/{api_id}/definitions/code/php/generate/path/parameters/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Filterpath != null){
        queryParams.Add("filterpath", apiInvoker.ParameterToString(Filterpath));
      }
      if (Filterverb != null){
        queryParams.Add("filterverb", apiInvoker.ParameterToString(Filterverb));
      }
      

      

      

      try {
        if (typeof(List<snippet>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<snippet>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<snippet>) ApiInvoker.deserialize(response, typeof(List<snippet>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
