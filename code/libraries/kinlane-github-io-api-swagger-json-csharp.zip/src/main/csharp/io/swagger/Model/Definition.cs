using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Definition {
    

    /* url for the definition */
    
    public string Url { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Definition {\n");
      
      sb.Append("  Url: ").Append(Url).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}