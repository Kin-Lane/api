using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class URLsApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public URLsApi(String basePath = "https://api.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// retrieve an APIs URLs retrieve an APIs URLs
    /// </summary>
    /// <param name="ApiId">id for the API</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<url>  GetAPIURLs (string ApiId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/api/{api_id}/urls/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<url>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<url>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<url>) ApiInvoker.deserialize(response, typeof(List<url>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add an API URL add an API URL
    /// </summary>
    /// <param name="ApiId">id for the API</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Type">type of url</param>
     /// <param name="Url">the url</param>
     /// <param name="Name">a name for the url</param>
    
    /// <returns></returns>
    public List<url>  AddAPIURL (string ApiId, string Appid, string Appkey, string Type, string Url, string Name) {
      // create path and map variables
      var path = "/api/{api_id}/urls/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Type != null){
        queryParams.Add("type", apiInvoker.ParameterToString(Type));
      }
      if (Url != null){
        queryParams.Add("url", apiInvoker.ParameterToString(Url));
      }
      if (Name != null){
        queryParams.Add("name", apiInvoker.ParameterToString(Name));
      }
      

      

      

      try {
        if (typeof(List<url>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<url>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<url>) ApiInvoker.deserialize(response, typeof(List<url>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete an API URL delete an API URL
    /// </summary>
    /// <param name="ApiId">id for the api item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="UrlId">id for the url</param>
    
    /// <returns></returns>
    public List<url>  DeleteAPIURL (string ApiId, string Appid, string Appkey, string UrlId) {
      // create path and map variables
      var path = "/api/{api_id}/urls/{url_id}".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId)).Replace("{" + "url_id" + "}", apiInvoker.ParameterToString(UrlId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<url>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<url>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<url>) ApiInvoker.deserialize(response, typeof(List<url>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
