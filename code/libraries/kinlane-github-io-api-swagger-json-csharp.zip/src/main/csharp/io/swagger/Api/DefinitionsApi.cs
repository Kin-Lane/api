using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class DefinitionsApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public DefinitionsApi(String basePath = "https://api.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// export an apis.json definition export an apis.json definition
    /// </summary>
    /// <param name="ApiId">id for the api item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<definition>  ExportAPIsJSON (string ApiId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/api/{api_id}/definitions/export/apisjson/.14/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<definition>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<definition>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<definition>) ApiInvoker.deserialize(response, typeof(List<definition>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// export an apis.json master definition export an apis.json master definition
    /// </summary>
    /// <param name="ApiId">id for the api item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<definition>  ExportAPIsJSONMaster (string ApiId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/api/{api_id}/definitions/export/apisjson/.14/master/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<definition>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<definition>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<definition>) ApiInvoker.deserialize(response, typeof(List<definition>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// export a Swagger 1.2 definition export a Swagger 1.2 definition
    /// </summary>
    /// <param name="ApiId">id for the api item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<definition>  ExportSwagger12Definition (string ApiId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/api/{api_id}/definitions/export/swagger/1.2/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<definition>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<definition>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<definition>) ApiInvoker.deserialize(response, typeof(List<definition>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// exports a Swagger 2.0 definition exports a Swagger 2.0 definition
    /// </summary>
    /// <param name="ApiId">id for the api item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<definition>  ExportSwagger20Definition (string ApiId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/api/{api_id}/definitions/export/swagger/2.0/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<definition>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<definition>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<definition>) ApiInvoker.deserialize(response, typeof(List<definition>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// imports a Swagger 1.2 definition imports a Swagger 1.2 definition
    /// </summary>
    /// <param name="ApiId">id for the api item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Url">url of the Swagger definition</param>
    
    /// <returns></returns>
    public List<definition>  ImportSwagger12Definition (string ApiId, string Appid, string Appkey, string Url) {
      // create path and map variables
      var path = "/api/{api_id}/definitions/import/swagger/1.2/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      

      

      if (Appid != null){
        if(Appid is byte[]) {
          formParams.Add("appid", Appid);
        } else {
          formParams.Add("appid", apiInvoker.ParameterToString(Appid));
        }
      }
      if (Appkey != null){
        if(Appkey is byte[]) {
          formParams.Add("appkey", Appkey);
        } else {
          formParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
        }
      }
      if (Url != null){
        if(Url is byte[]) {
          formParams.Add("url", Url);
        } else {
          formParams.Add("url", apiInvoker.ParameterToString(Url));
        }
      }
      

      try {
        if (typeof(List<definition>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<definition>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<definition>) ApiInvoker.deserialize(response, typeof(List<definition>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// import a Swagger 2.0 definition import a Swagger 2.0 definition
    /// </summary>
    /// <param name="ApiId">id for the api item</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Url">url of the Swagger definition</param>
    
    /// <returns></returns>
    public List<definition>  ImportSwagger20Definition (string ApiId, string Appid, string Appkey, string Url) {
      // create path and map variables
      var path = "/api/{api_id}/definitions/import/swagger/2.0/".Replace("{format}","json").Replace("{" + "api_id" + "}", apiInvoker.ParameterToString(ApiId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      

      

      if (Appid != null){
        if(Appid is byte[]) {
          formParams.Add("appid", Appid);
        } else {
          formParams.Add("appid", apiInvoker.ParameterToString(Appid));
        }
      }
      if (Appkey != null){
        if(Appkey is byte[]) {
          formParams.Add("appkey", Appkey);
        } else {
          formParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
        }
      }
      if (Url != null){
        if(Url is byte[]) {
          formParams.Add("url", Url);
        } else {
          formParams.Add("url", apiInvoker.ParameterToString(Url));
        }
      }
      

      try {
        if (typeof(List<definition>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<definition>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<definition>) ApiInvoker.deserialize(response, typeof(List<definition>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
