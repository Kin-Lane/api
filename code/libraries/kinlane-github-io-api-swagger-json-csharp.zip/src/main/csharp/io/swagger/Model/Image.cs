using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Image {
    

    /* name of the image */
    
    public string Name { get; set; }

    

    /* path of the image */
    
    public string Path { get; set; }

    

    /* type of image */
    
    public string Type { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Image {\n");
      
      sb.Append("  Name: ").Append(Name).Append("\n");
      
      sb.Append("  Path: ").Append(Path).Append("\n");
      
      sb.Append("  Type: ").Append(Type).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}