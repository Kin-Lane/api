package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Note;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class NotesApi {
  String basePath = "https://api.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * retrieve an APIs notes
   * retrieve an APIs notes
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @return List<Note>
   */
  public List<Note> getAPINotes (String apiId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/notes/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Note>) ApiInvoker.deserialize(response, "array", Note.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add an API note
   * add an API note
   * @param apiId id for the api item
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param type type of the note
   * @param note the full text of note
   * @return List<Note>
   */
  public List<Note> addAPINote (String apiId, String appid, String appkey, String type, String note) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/notes/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (type != null)
      queryParams.put("type", ApiInvoker.parameterToString(type));
    if (note != null)
      queryParams.put("note", ApiInvoker.parameterToString(note));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Note>) ApiInvoker.deserialize(response, "array", Note.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete an API note
   * delete an API note
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param noteId id for the note
   * @return List<Note>
   */
  public List<Note> deleteAPINote (String apiId, String appid, String appkey, String noteId) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/notes/{note_id}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()))
      .replaceAll("\\{" + "noteId" + "\\}", apiInvoker.escapeString(noteId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Note>) ApiInvoker.deserialize(response, "array", Note.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
