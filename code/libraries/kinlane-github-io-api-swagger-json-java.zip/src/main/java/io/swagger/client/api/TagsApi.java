package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Tag;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class TagsApi {
  String basePath = "https://api.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * retrieve API tags
   * retrieve API tags
   * @param apiId id for API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @return List<Tag>
   */
  public List<Tag> getAPITags (String apiId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/tags/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Tag>) ApiInvoker.deserialize(response, "array", Tag.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add tag to API
   * add tag to API
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param tag tag name
   * @return List<Tag>
   */
  public List<Tag> addAPITag (String apiId, String appid, String appkey, String tag) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/tags/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (tag != null)
      queryParams.put("tag", ApiInvoker.parameterToString(tag));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Tag>) ApiInvoker.deserialize(response, "array", Tag.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete an API tag
   * delete an API tag
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param tag tag to remove from API
   * @return List<Tag>
   */
  public List<Tag> deleteAPITag (String apiId, String appid, String appkey, String tag) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/tags/{tag}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()))
      .replaceAll("\\{" + "tag" + "\\}", apiInvoker.escapeString(tag.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Tag>) ApiInvoker.deserialize(response, "array", Tag.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
