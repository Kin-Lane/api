package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Api;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class APIApi {
  String basePath = "https://api.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * retrieves all apis
   * retrieves all apis
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param query a text query to search across APIs
   * @return List<Api>
   */
  public List<Api> getAPIs (String appid, String appkey, String query) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (query != null)
      queryParams.put("query", ApiInvoker.parameterToString(query));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Api>) ApiInvoker.deserialize(response, "array", Api.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add api
   * add api
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param name name of the API
   * @param about details about the API
   * @param rank ranking of API
   * @param organizationId organization ID for the API
   * @return List<Api>
   */
  public List<Api> addAPI (String appid, String appkey, String name, String about, String rank, String organizationId) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (name != null)
      queryParams.put("name", ApiInvoker.parameterToString(name));
    if (about != null)
      queryParams.put("about", ApiInvoker.parameterToString(about));
    if (rank != null)
      queryParams.put("rank", ApiInvoker.parameterToString(rank));
    if (organizationId != null)
      queryParams.put("organization_id", ApiInvoker.parameterToString(organizationId));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Api>) ApiInvoker.deserialize(response, "array", Api.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * retrieve an API
   * retrieve an API
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @return List<Api>
   */
  public List<Api> getAPI (String apiId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Api>) ApiInvoker.deserialize(response, "array", Api.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * update an API
   * update an API
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param name name of the API
   * @param about details about the API
   * @param rank ranking of API
   * @param organizationId organization ID for the API
   * @return List<Api>
   */
  public List<Api> updateAPI (String apiId, String appid, String appkey, String name, String about, String rank, String organizationId) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (name != null)
      queryParams.put("name", ApiInvoker.parameterToString(name));
    if (about != null)
      queryParams.put("about", ApiInvoker.parameterToString(about));
    if (rank != null)
      queryParams.put("rank", ApiInvoker.parameterToString(rank));
    if (organizationId != null)
      queryParams.put("organization_id", ApiInvoker.parameterToString(organizationId));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Api>) ApiInvoker.deserialize(response, "array", Api.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete an API
   * delete an API
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @return List<Api>
   */
  public List<Api> deleteAPI (String apiId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Api>) ApiInvoker.deserialize(response, "array", Api.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
