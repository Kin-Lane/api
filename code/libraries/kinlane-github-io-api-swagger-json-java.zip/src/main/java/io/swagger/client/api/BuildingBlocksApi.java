package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Buildingblock;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class BuildingBlocksApi {
  String basePath = "https://api.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * retrieve an APIs building blocks
   * retrieve an APIs building blocks
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @return List<Buildingblock>
   */
  public List<Buildingblock> getAPIBuildingBlocks (String apiId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/buildingblocks/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Buildingblock>) ApiInvoker.deserialize(response, "array", Buildingblock.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add an API building block
   * add an API building block
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param buildingBlockApi id for the building block
   * @param organizationId id for the organization
   * @param toolId id for the tool
   * @param url the url for the building block
   * @return List<Buildingblock>
   */
  public List<Buildingblock> addAPIBuildingBlock (String apiId, String appid, String appkey, Integer buildingBlockApi, Integer organizationId, Integer toolId, String url) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/buildingblocks/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (buildingBlockApi != null)
      queryParams.put("building_block_api", ApiInvoker.parameterToString(buildingBlockApi));
    if (organizationId != null)
      queryParams.put("organization_id", ApiInvoker.parameterToString(organizationId));
    if (toolId != null)
      queryParams.put("tool_id", ApiInvoker.parameterToString(toolId));
    if (url != null)
      queryParams.put("url", ApiInvoker.parameterToString(url));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Buildingblock>) ApiInvoker.deserialize(response, "array", Buildingblock.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete an API building block
   * delete an API building block
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param buildingblockId id for the building block
   * @return List<Buildingblock>
   */
  public List<Buildingblock> deleteAPIBuildingBlocks (String apiId, String appid, String appkey, String buildingblockId) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/buildingblocks/{buildingblock_id}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()))
      .replaceAll("\\{" + "buildingblockId" + "\\}", apiInvoker.escapeString(buildingblockId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Buildingblock>) ApiInvoker.deserialize(response, "array", Buildingblock.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
