package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Image;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class ImagesApi {
  String basePath = "https://api.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * retrieve an APIs images
   * retrieve an APIs images
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @return List<Image>
   */
  public List<Image> getAPIImages (String apiId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/images/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Image>) ApiInvoker.deserialize(response, "array", Image.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add an API image
   * add an API image
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param name name of the image
   * @param path path of the image
   * @param type type of image
   * @return List<Image>
   */
  public List<Image> addAPIImage (String apiId, String appid, String appkey, String name, String path, String type) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/images/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (name != null)
      queryParams.put("name", ApiInvoker.parameterToString(name));
    if (path != null)
      queryParams.put("path", ApiInvoker.parameterToString(path));
    if (type != null)
      queryParams.put("type", ApiInvoker.parameterToString(type));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Image>) ApiInvoker.deserialize(response, "array", Image.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete an API image
   * delete an API image
   * @param apiId id for the API
   * @param appid your appid for accessing the API
   * @param appkey your appkey for accessing the API
   * @param imageId id for the image
   * @return List<Image>
   */
  public List<Image> deleteAPIImage (String apiId, String appid, String appkey, String imageId) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/api/{api_id}/images/{image_id}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "apiId" + "\\}", apiInvoker.escapeString(apiId.toString()))
      .replaceAll("\\{" + "imageId" + "\\}", apiInvoker.escapeString(imageId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Image>) ApiInvoker.deserialize(response, "array", Image.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
