package io.swagger.client.model;


import com.wordnik.swagger.annotations.*;
import com.fasterxml.jackson.annotation.JsonProperty;


@ApiModel(description = "")
public class Api  {
  
  private String title = null;
  private String link = null;
  private String itemDate = null;

  
  /**
   * title of the api item
   **/
  @ApiModelProperty(value = "title of the api item")
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }

  
  /**
   * url for the api item
   **/
  @ApiModelProperty(value = "url for the api item")
  @JsonProperty("link")
  public String getLink() {
    return link;
  }
  public void setLink(String link) {
    this.link = link;
  }

  
  /**
   * date applied to the api item
   **/
  @ApiModelProperty(value = "date applied to the api item")
  @JsonProperty("item_date")
  public String getItemDate() {
    return itemDate;
  }
  public void setItemDate(String itemDate) {
    this.itemDate = itemDate;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Api {\n");
    
    sb.append("  title: ").append(title).append("\n");
    sb.append("  link: ").append(link).append("\n");
    sb.append("  itemDate: ").append(itemDate).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
