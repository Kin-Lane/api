#import <Foundation/Foundation.h>
#import "SWGBuildingblock.h"
#import "SWGObject.h"


@interface SWGBuildingBlocksApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGBuildingBlocksApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve an APIs building blocks
 retrieve an APIs building blocks

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGBuildingblock>*
 */
-(NSNumber*) getAPIBuildingBlocksWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGBuildingblock>* output, NSError* error))completionBlock;
    


/**

 add an API building block
 add an API building block

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param building_block_api id for the building block
 @param organization_id id for the organization
 @param tool_id id for the tool
 @param url the url for the building block
 

 return type: NSArray<SWGBuildingblock>*
 */
-(NSNumber*) addAPIBuildingBlockWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     building_block_api:(NSNumber*) building_block_api 
     organization_id:(NSNumber*) organization_id 
     tool_id:(NSNumber*) tool_id 
     url:(NSString*) url 
    
    completionHandler: (void (^)(NSArray<SWGBuildingblock>* output, NSError* error))completionBlock;
    


/**

 delete an API building block
 delete an API building block

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param buildingblock_id id for the building block
 

 return type: NSArray<SWGBuildingblock>*
 */
-(NSNumber*) deleteAPIBuildingBlocksWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     buildingblock_id:(NSString*) buildingblock_id 
    
    completionHandler: (void (^)(NSArray<SWGBuildingblock>* output, NSError* error))completionBlock;
    



@end