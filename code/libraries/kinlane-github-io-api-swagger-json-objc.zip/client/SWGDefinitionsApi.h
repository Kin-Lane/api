#import <Foundation/Foundation.h>
#import "SWGDefinition.h"
#import "SWGObject.h"


@interface SWGDefinitionsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGDefinitionsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 export an apis.json definition
 export an apis.json definition

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGDefinition>*
 */
-(NSNumber*) exportAPIsJSONWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGDefinition>* output, NSError* error))completionBlock;
    


/**

 export an apis.json master definition
 export an apis.json master definition

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGDefinition>*
 */
-(NSNumber*) exportAPIsJSONMasterWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGDefinition>* output, NSError* error))completionBlock;
    


/**

 export a Swagger 1.2 definition
 export a Swagger 1.2 definition

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGDefinition>*
 */
-(NSNumber*) exportSwagger12DefinitionWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGDefinition>* output, NSError* error))completionBlock;
    


/**

 exports a Swagger 2.0 definition
 exports a Swagger 2.0 definition

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGDefinition>*
 */
-(NSNumber*) exportSwagger20DefinitionWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGDefinition>* output, NSError* error))completionBlock;
    


/**

 imports a Swagger 1.2 definition
 imports a Swagger 1.2 definition

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param url url of the Swagger definition
 

 return type: NSArray<SWGDefinition>*
 */
-(NSNumber*) importSwagger12DefinitionWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     url:(NSString*) url 
    
    completionHandler: (void (^)(NSArray<SWGDefinition>* output, NSError* error))completionBlock;
    


/**

 import a Swagger 2.0 definition
 import a Swagger 2.0 definition

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param url url of the Swagger definition
 

 return type: NSArray<SWGDefinition>*
 */
-(NSNumber*) importSwagger20DefinitionWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     url:(NSString*) url 
    
    completionHandler: (void (^)(NSArray<SWGDefinition>* output, NSError* error))completionBlock;
    



@end