#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGApi
@end
  
@interface SWGApi : SWGObject

/* title of the api item [optional]
 */
@property(nonatomic) NSString* title;
/* url for the api item [optional]
 */
@property(nonatomic) NSString* link;
/* date applied to the api item [optional]
 */
@property(nonatomic) NSString* item_date;

@end
