#import <Foundation/Foundation.h>
#import "SWGSnippet.h"
#import "SWGObject.h"


@interface SWGDefinitionCodeApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGDefinitionCodeApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 generate php array parameters
 generate php array parameters

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param filterobject the api definition object to filter by
 

 return type: NSArray<SWGSnippet>*
 */
-(NSNumber*) generatePHPArrayParametersWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     filterobject:(NSString*) filterobject 
    
    completionHandler: (void (^)(NSArray<SWGSnippet>* output, NSError* error))completionBlock;
    


/**

 generate php array parameters
 generate php array parameters

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param filterpath the api path to filter by
 @param filterverb the api verb to filter by
 

 return type: NSArray<SWGSnippet>*
 */
-(NSNumber*) generatePHPArrayParameters_1WithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     filterpath:(NSString*) filterpath 
     filterverb:(NSString*) filterverb 
    
    completionHandler: (void (^)(NSArray<SWGSnippet>* output, NSError* error))completionBlock;
    



@end