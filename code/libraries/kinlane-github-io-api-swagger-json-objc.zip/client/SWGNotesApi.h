#import <Foundation/Foundation.h>
#import "SWGNote.h"
#import "SWGObject.h"


@interface SWGNotesApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGNotesApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve an APIs notes
 retrieve an APIs notes

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGNote>*
 */
-(NSNumber*) getAPINotesWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGNote>* output, NSError* error))completionBlock;
    


/**

 add an API note
 add an API note

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param type type of the note
 @param note the full text of note
 

 return type: NSArray<SWGNote>*
 */
-(NSNumber*) addAPINoteWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     type:(NSString*) type 
     note:(NSString*) note 
    
    completionHandler: (void (^)(NSArray<SWGNote>* output, NSError* error))completionBlock;
    


/**

 delete an API note
 delete an API note

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param note_id id for the note
 

 return type: NSArray<SWGNote>*
 */
-(NSNumber*) deleteAPINoteWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     note_id:(NSString*) note_id 
    
    completionHandler: (void (^)(NSArray<SWGNote>* output, NSError* error))completionBlock;
    



@end