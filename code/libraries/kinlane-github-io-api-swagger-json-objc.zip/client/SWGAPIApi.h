#import <Foundation/Foundation.h>
#import "SWGApi.h"
#import "SWGObject.h"


@interface SWGAPIApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGAPIApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieves all apis
 retrieves all apis

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param query a text query to search across APIs
 

 return type: NSArray<SWGApi>*
 */
-(NSNumber*) getAPIsWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     query:(NSString*) query 
    
    completionHandler: (void (^)(NSArray<SWGApi>* output, NSError* error))completionBlock;
    


/**

 add api
 add api

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param name name of the API
 @param about details about the API
 @param rank ranking of API
 @param organization_id organization ID for the API
 

 return type: NSArray<SWGApi>*
 */
-(NSNumber*) addAPIWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     name:(NSString*) name 
     about:(NSString*) about 
     rank:(NSString*) rank 
     organization_id:(NSString*) organization_id 
    
    completionHandler: (void (^)(NSArray<SWGApi>* output, NSError* error))completionBlock;
    


/**

 retrieve an API
 retrieve an API

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGApi>*
 */
-(NSNumber*) getAPIWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGApi>* output, NSError* error))completionBlock;
    


/**

 update an API
 update an API

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param name name of the API
 @param about details about the API
 @param rank ranking of API
 @param organization_id organization ID for the API
 

 return type: NSArray<SWGApi>*
 */
-(NSNumber*) updateAPIWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     name:(NSString*) name 
     about:(NSString*) about 
     rank:(NSString*) rank 
     organization_id:(NSString*) organization_id 
    
    completionHandler: (void (^)(NSArray<SWGApi>* output, NSError* error))completionBlock;
    


/**

 delete an API
 delete an API

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGApi>*
 */
-(NSNumber*) deleteAPIWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGApi>* output, NSError* error))completionBlock;
    



@end