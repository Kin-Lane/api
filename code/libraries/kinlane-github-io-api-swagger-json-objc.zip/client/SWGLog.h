#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGLog
@end
  
@interface SWGLog : SWGObject

/* type of log [optional]
 */
@property(nonatomic) NSString* type;
/* text of note [optional]
 */
@property(nonatomic) NSString* note;
/* details of log [optional]
 */
@property(nonatomic) NSString* details;
/* log date [optional]
 */
@property(nonatomic) NSString* log_date;

@end
