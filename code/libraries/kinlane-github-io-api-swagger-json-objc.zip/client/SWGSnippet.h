#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGSnippet
@end
  
@interface SWGSnippet : SWGObject

/* content of the snippet [optional]
 */
@property(nonatomic) NSString* content;

@end
