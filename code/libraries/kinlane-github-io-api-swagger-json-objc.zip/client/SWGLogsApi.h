#import <Foundation/Foundation.h>
#import "SWGLog.h"
#import "SWGObject.h"


@interface SWGLogsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGLogsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve an APIs logs
 retrieve an APIs logs

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGLog>*
 */
-(NSNumber*) getAPILogsWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGLog>* output, NSError* error))completionBlock;
    


/**

 add an API log
 add an API log

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param type type of log entry
 @param details log details
 @param log_date date of the log entry
 

 return type: NSArray<SWGLog>*
 */
-(NSNumber*) addAPILogWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     type:(NSString*) type 
     details:(NSString*) details 
     log_date:(NSString*) log_date 
    
    completionHandler: (void (^)(NSArray<SWGLog>* output, NSError* error))completionBlock;
    


/**

 delete an API log
 delete an API log

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param log_id id for the log
 

 return type: NSArray<SWGLog>*
 */
-(NSNumber*) deleteAPILogWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     log_id:(NSString*) log_id 
    
    completionHandler: (void (^)(NSArray<SWGLog>* output, NSError* error))completionBlock;
    



@end