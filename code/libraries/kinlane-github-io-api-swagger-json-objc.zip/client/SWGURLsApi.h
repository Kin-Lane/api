#import <Foundation/Foundation.h>
#import "SWGUrl.h"
#import "SWGObject.h"


@interface SWGURLsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGURLsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve an APIs URLs
 retrieve an APIs URLs

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGUrl>*
 */
-(NSNumber*) getAPIURLsWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGUrl>* output, NSError* error))completionBlock;
    


/**

 add an API URL
 add an API URL

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param type type of url
 @param url the url
 @param name a name for the url
 

 return type: NSArray<SWGUrl>*
 */
-(NSNumber*) addAPIURLWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     type:(NSString*) type 
     url:(NSString*) url 
     name:(NSString*) name 
    
    completionHandler: (void (^)(NSArray<SWGUrl>* output, NSError* error))completionBlock;
    


/**

 delete an API URL
 delete an API URL

 @param api_id id for the api item
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param url_id id for the url
 

 return type: NSArray<SWGUrl>*
 */
-(NSNumber*) deleteAPIURLWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     url_id:(NSString*) url_id 
    
    completionHandler: (void (^)(NSArray<SWGUrl>* output, NSError* error))completionBlock;
    



@end