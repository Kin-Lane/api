#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGBuildingblock
@end
  
@interface SWGBuildingblock : SWGObject

/* url of the building block [optional]
 */
@property(nonatomic) NSString* url;

@end
