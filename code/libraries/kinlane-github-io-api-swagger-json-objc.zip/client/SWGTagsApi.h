#import <Foundation/Foundation.h>
#import "SWGTag.h"
#import "SWGObject.h"


@interface SWGTagsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGTagsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve API tags
 retrieve API tags

 @param api_id id for API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) getAPITagsWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 add tag to API
 add tag to API

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param tag tag name
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) addAPITagWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 delete an API tag
 delete an API tag

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param tag tag to remove from API
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) deleteAPITagWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    



@end