#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGDefinition
@end
  
@interface SWGDefinition : SWGObject

/* url for the definition [optional]
 */
@property(nonatomic) NSString* url;

@end
