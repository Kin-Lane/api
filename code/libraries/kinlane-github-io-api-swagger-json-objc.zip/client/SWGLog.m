#import "SWGLog.h"

@implementation SWGLog
  
+ (JSONKeyMapper *)keyMapper
{
  return [[JSONKeyMapper alloc] initWithDictionary:@{ @"type": @"type", @"note": @"note", @"details": @"details", @"log_date": @"log_date" }];
}

+ (BOOL)propertyIsOptional:(NSString *)propertyName
{
  NSArray *optionalProperties = @[@"type", @"note", @"details", @"log_date"];

  if ([optionalProperties containsObject:propertyName]) {
    return YES;
  }
  else {
    return NO;
  }
}

@end
