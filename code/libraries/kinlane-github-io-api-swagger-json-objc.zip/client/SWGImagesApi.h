#import <Foundation/Foundation.h>
#import "SWGImage.h"
#import "SWGObject.h"


@interface SWGImagesApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGImagesApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve an APIs images
 retrieve an APIs images

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGImage>*
 */
-(NSNumber*) getAPIImagesWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGImage>* output, NSError* error))completionBlock;
    


/**

 add an API image
 add an API image

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param name name of the image
 @param path path of the image
 @param type type of image
 

 return type: NSArray<SWGImage>*
 */
-(NSNumber*) addAPIImageWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     name:(NSString*) name 
     path:(NSString*) path 
     type:(NSString*) type 
    
    completionHandler: (void (^)(NSArray<SWGImage>* output, NSError* error))completionBlock;
    


/**

 delete an API image
 delete an API image

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param image_id id for the image
 

 return type: NSArray<SWGImage>*
 */
-(NSNumber*) deleteAPIImageWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     image_id:(NSString*) image_id 
    
    completionHandler: (void (^)(NSArray<SWGImage>* output, NSError* error))completionBlock;
    



@end