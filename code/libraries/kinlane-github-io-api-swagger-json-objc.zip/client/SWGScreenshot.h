#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGScreenshot
@end
  
@interface SWGScreenshot : SWGObject

/* name of the screenshot [optional]
 */
@property(nonatomic) NSString* name;
/* path of the screenshot [optional]
 */
@property(nonatomic) NSString* path;
/* type of screenshot [optional]
 */
@property(nonatomic) NSString* type;

@end
