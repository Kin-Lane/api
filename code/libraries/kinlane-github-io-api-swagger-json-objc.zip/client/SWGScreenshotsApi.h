#import <Foundation/Foundation.h>
#import "SWGScreenshot.h"
#import "SWGObject.h"


@interface SWGScreenshotsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGScreenshotsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve API screenshots
 retrieve API screenshots

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGScreenshot>*
 */
-(NSNumber*) getAPIScreenshotsWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGScreenshot>* output, NSError* error))completionBlock;
    


/**

 add an API screenshot
 add an API screenshot

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param name name of the screenshot
 @param path path of the screenshot
 @param type type of screenshot
 

 return type: NSArray<SWGScreenshot>*
 */
-(NSNumber*) addAPIScreenshotWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     name:(NSString*) name 
     path:(NSString*) path 
     type:(NSString*) type 
    
    completionHandler: (void (^)(NSArray<SWGScreenshot>* output, NSError* error))completionBlock;
    


/**

 delete an API screenshot
 delete an API screenshot

 @param api_id id for the API
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param screenshot_id id for the screenshot
 

 return type: NSArray<SWGScreenshot>*
 */
-(NSNumber*) deleteAPIScreenshotWithCompletionBlock :(NSString*) api_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     screenshot_id:(NSString*) screenshot_id 
    
    completionHandler: (void (^)(NSArray<SWGScreenshot>* output, NSError* error))completionBlock;
    



@end