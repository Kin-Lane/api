
class Api
  attr_accessor :title, :link, :item_date
  # :internal => :external
  def self.attribute_map
    {
      :title => :'title',
      :link => :'link',
      :item_date => :'item_date'
      
    }
  end

  def initialize(attributes = {})
    return if attributes.empty?
    # Morph attribute keys into undescored rubyish style
    
    if self.class.attribute_map[:"title"]
      @title = attributes["title"]
    end
    
    if self.class.attribute_map[:"link"]
      @link = attributes["link"]
    end
    
    if self.class.attribute_map[:"item_date"]
      @item_date = attributes["item_date"]
    end
    
  end

  def to_body
    body = {}
    self.class.attribute_map.each_pair do |key, value|
      body[value] = self.send(key) unless self.send(key).nil?
    end
    body
  end
end
