
class Log
  attr_accessor :type, :note, :details, :log_date
  # :internal => :external
  def self.attribute_map
    {
      :type => :'type',
      :note => :'note',
      :details => :'details',
      :log_date => :'log_date'
      
    }
  end

  def initialize(attributes = {})
    return if attributes.empty?
    # Morph attribute keys into undescored rubyish style
    
    if self.class.attribute_map[:"type"]
      @type = attributes["type"]
    end
    
    if self.class.attribute_map[:"note"]
      @note = attributes["note"]
    end
    
    if self.class.attribute_map[:"details"]
      @details = attributes["details"]
    end
    
    if self.class.attribute_map[:"log_date"]
      @log_date = attributes["log_date"]
    end
    
  end

  def to_body
    body = {}
    self.class.attribute_map.each_pair do |key, value|
      body[value] = self.send(key) unless self.send(key).nil?
    end
    body
  end
end
