require "uri"

class APIApi
  basePath = "https://api.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # retrieves all apis
  # retrieves all apis
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param query a text query to search across APIs
  # @param [Hash] opts the optional parameters
  # @return array[api]
  def self.get_ap_is(appid, appkey, query, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "query is required" if query.nil?

    # resource path
    path = "/api/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'query'] = query

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| api.new(response) }
  end

  # add api
  # add api
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param name name of the API
  # @param about details about the API
  # @param rank ranking of API
  # @param organization_id organization ID for the API
  # @param [Hash] opts the optional parameters
  # @return array[api]
  def self.add_api(appid, appkey, name, about, rank, organization_id, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "name is required" if name.nil?
    raise "about is required" if about.nil?
    raise "rank is required" if rank.nil?
    raise "organization_id is required" if organization_id.nil?

    # resource path
    path = "/api/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'name'] = name
    query_params[:'about'] = about
    query_params[:'rank'] = rank
    query_params[:'organization_id'] = organization_id

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| api.new(response) }
  end

  # retrieve an API
  # retrieve an API
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[api]
  def self.get_api(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| api.new(response) }
  end

  # update an API
  # update an API
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param name name of the API
  # @param about details about the API
  # @param rank ranking of API
  # @param organization_id organization ID for the API
  # @param [Hash] opts the optional parameters
  # @return array[api]
  def self.update_api(api_id, appid, appkey, name, about, rank, organization_id, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "name is required" if name.nil?
    raise "about is required" if about.nil?
    raise "rank is required" if rank.nil?
    raise "organization_id is required" if organization_id.nil?

    # resource path
    path = "/api/{api_id}/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'name'] = name
    query_params[:'about'] = about
    query_params[:'rank'] = rank
    query_params[:'organization_id'] = organization_id

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:PUT, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| api.new(response) }
  end

  # delete an API
  # delete an API
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[api]
  def self.delete_api(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| api.new(response) }
  end
end
