require "uri"

class DefinitionsApi
  basePath = "https://api.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # export an apis.json definition
  # export an apis.json definition
  # @param api_id id for the api item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[definition]
  def self.export_ap_is_json(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/definitions/export/apisjson/.14/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| definition.new(response) }
  end

  # export an apis.json master definition
  # export an apis.json master definition
  # @param api_id id for the api item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[definition]
  def self.export_ap_is_json_master(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/definitions/export/apisjson/.14/master/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| definition.new(response) }
  end

  # export a Swagger 1.2 definition
  # export a Swagger 1.2 definition
  # @param api_id id for the api item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[definition]
  def self.export_swagger12_definition(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/definitions/export/swagger/1.2/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| definition.new(response) }
  end

  # exports a Swagger 2.0 definition
  # exports a Swagger 2.0 definition
  # @param api_id id for the api item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[definition]
  def self.export_swagger20_definition(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/definitions/export/swagger/2.0/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| definition.new(response) }
  end

  # imports a Swagger 1.2 definition
  # imports a Swagger 1.2 definition
  # @param api_id id for the api item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param url url of the Swagger definition
  # @param [Hash] opts the optional parameters
  # @return array[definition]
  def self.import_swagger12_definition(api_id, appid, appkey, url, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "url is required" if url.nil?

    # resource path
    path = "/api/{api_id}/definitions/import/swagger/1.2/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}
    form_params["appid"] = appid
    form_params["appkey"] = appkey
    form_params["url"] = url

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| definition.new(response) }
  end

  # import a Swagger 2.0 definition
  # import a Swagger 2.0 definition
  # @param api_id id for the api item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param url url of the Swagger definition
  # @param [Hash] opts the optional parameters
  # @return array[definition]
  def self.import_swagger20_definition(api_id, appid, appkey, url, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "url is required" if url.nil?

    # resource path
    path = "/api/{api_id}/definitions/import/swagger/2.0/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}
    form_params["appid"] = appid
    form_params["appkey"] = appkey
    form_params["url"] = url

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| definition.new(response) }
  end
end
