require "uri"

class LogsApi
  basePath = "https://api.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # retrieve an APIs logs
  # retrieve an APIs logs
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[log]
  def self.get_api_logs(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/logs/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| log.new(response) }
  end

  # add an API log
  # add an API log
  # @param api_id id for the api item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param log_date date of the log entry
  # @param [Hash] opts the optional parameters
  # @option opts [string] :type type of log entry
  # @option opts [string] :details log details
  # @return array[log]
  def self.add_api_log(api_id, appid, appkey, log_date, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "log_date is required" if log_date.nil?

    # resource path
    path = "/api/{api_id}/logs/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'log_date'] = log_date
    query_params[:'type'] = opts[:'type'] if opts[:'type']
    query_params[:'details'] = opts[:'details'] if opts[:'details']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| log.new(response) }
  end

  # delete an API log
  # delete an API log
  # @param api_id id for the api item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param log_id id for the log
  # @param [Hash] opts the optional parameters
  # @return array[log]
  def self.delete_api_log(api_id, appid, appkey, log_id, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "log_id is required" if log_id.nil?

    # resource path
    path = "/api/{api_id}/logs/{log_id}".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s).sub('{' + 'log_id' + '}', log_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| log.new(response) }
  end
end
