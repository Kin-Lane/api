require "uri"

class DefinitionCodeApi
  basePath = "https://api.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # generate php array parameters
  # generate php array parameters
  # @param api_id id for the api item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @option opts [string] :filterobject the api definition object to filter by
  # @return array[snippet]
  def self.generate_php_array_parameters(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/definitions/code/php/generate/definition/parameters/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'filterobject'] = opts[:'filterobject'] if opts[:'filterobject']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| snippet.new(response) }
  end

  # generate php array parameters
  # generate php array parameters
  # @param api_id id for the api item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @option opts [string] :filterpath the api path to filter by
  # @option opts [string] :filterverb the api verb to filter by
  # @return array[snippet]
  def self.generate_php_array_parameters_1(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/definitions/code/php/generate/path/parameters/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'filterpath'] = opts[:'filterpath'] if opts[:'filterpath']
    query_params[:'filterverb'] = opts[:'filterverb'] if opts[:'filterverb']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| snippet.new(response) }
  end
end
