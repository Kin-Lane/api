require "uri"

class ImagesApi
  basePath = "https://api.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # retrieve an APIs images
  # retrieve an APIs images
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[image]
  def self.get_api_images(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/images/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| image.new(response) }
  end

  # add an API image
  # add an API image
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param name name of the image
  # @param path path of the image
  # @param type type of image
  # @param [Hash] opts the optional parameters
  # @return array[image]
  def self.add_api_image(api_id, appid, appkey, name, path, type, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "name is required" if name.nil?
    raise "path is required" if path.nil?
    raise "type is required" if type.nil?

    # resource path
    path = "/api/{api_id}/images/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'name'] = name
    query_params[:'path'] = path
    query_params[:'type'] = type

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| image.new(response) }
  end

  # delete an API image
  # delete an API image
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param image_id id for the image
  # @param [Hash] opts the optional parameters
  # @return array[image]
  def self.delete_api_image(api_id, appid, appkey, image_id, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "image_id is required" if image_id.nil?

    # resource path
    path = "/api/{api_id}/images/{image_id}".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s).sub('{' + 'image_id' + '}', image_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| image.new(response) }
  end
end
