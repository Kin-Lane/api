require "uri"

class ScreenshotsApi
  basePath = "https://api.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # retrieve API screenshots
  # retrieve API screenshots
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[screenshot]
  def self.get_api_screenshots(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/screenshots/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| screenshot.new(response) }
  end

  # add an API screenshot
  # add an API screenshot
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param name name of the screenshot
  # @param path path of the screenshot
  # @param type type of screenshot
  # @param [Hash] opts the optional parameters
  # @return array[screenshot]
  def self.add_api_screenshot(api_id, appid, appkey, name, path, type, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "name is required" if name.nil?
    raise "path is required" if path.nil?
    raise "type is required" if type.nil?

    # resource path
    path = "/api/{api_id}/screenshots/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'name'] = name
    query_params[:'path'] = path
    query_params[:'type'] = type

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| screenshot.new(response) }
  end

  # delete an API screenshot
  # delete an API screenshot
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param screenshot_id id for the screenshot
  # @param [Hash] opts the optional parameters
  # @return array[screenshot]
  def self.delete_api_screenshot(api_id, appid, appkey, screenshot_id, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "screenshot_id is required" if screenshot_id.nil?

    # resource path
    path = "/api/{api_id}/screenshots/{screenshot_id}".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s).sub('{' + 'screenshot_id' + '}', screenshot_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| screenshot.new(response) }
  end
end
