module Swagger
  VERSION = "4.06.08"
end

