require "uri"

class URLsApi
  basePath = "https://api.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # retrieve an APIs URLs
  # retrieve an APIs URLs
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[url]
  def self.get_apiur_ls(api_id, appid, appkey, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/api/{api_id}/urls/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| url.new(response) }
  end

  # add an API URL
  # add an API URL
  # @param api_id id for the API
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param type type of url
  # @param url the url
  # @param name a name for the url
  # @param [Hash] opts the optional parameters
  # @return array[url]
  def self.add_apiurl(api_id, appid, appkey, type, url, name, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "type is required" if type.nil?
    raise "url is required" if url.nil?
    raise "name is required" if name.nil?

    # resource path
    path = "/api/{api_id}/urls/".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'type'] = type
    query_params[:'url'] = url
    query_params[:'name'] = name

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| url.new(response) }
  end

  # delete an API URL
  # delete an API URL
  # @param api_id id for the api item
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param url_id id for the url
  # @param [Hash] opts the optional parameters
  # @return array[url]
  def self.delete_apiurl(api_id, appid, appkey, url_id, opts = {})
    # verify existence of params
    raise "api_id is required" if api_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "url_id is required" if url_id.nil?

    # resource path
    path = "/api/{api_id}/urls/{url_id}".sub('{format}','json').sub('{' + 'api_id' + '}', api_id.to_s).sub('{' + 'url_id' + '}', url_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| url.new(response) }
  end
end
